
char sujet[10][50]={"le poisson rouge",
		"un etudiant",
		"le prof",
		"la petite voiture",
		"Alfred",
		"Oscar",
		"Guillaume H.",
		"le president de le Blicpuree",
		"elle",
		"un inconnu"} ;

char verbe[10][50]={"avale bruyamment",
		"apprend",
		"trouve enfin",
		"essuie nerveusement",
		"fixe",
		"joue avec",
		"chauffe",
		"regarde d'un air soupconneux",
		"fait un selfie avec",
		"cogne sur"} ;

char complement[10][50]={"la roue de secours",
		"son steack-frites",
		"une bille verte",
		"les yeux du pharmacien",
		"son binome",
		"le sujet du TP de INF203",
		"Julie",
		"mes nouvelles chaussures",
		"la fumee qui sort du clavier",
		"la cle son antivol"} ;

