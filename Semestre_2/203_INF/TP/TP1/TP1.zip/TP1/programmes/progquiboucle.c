#include <stdio.h>

main()
{
   while (1)
   {
        printf("je tourne en rond\n");
   }
}
