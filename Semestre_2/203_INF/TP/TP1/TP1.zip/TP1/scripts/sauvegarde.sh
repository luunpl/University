#!/bin/bash
cd $HOME/INF203
cp -r TP1 sauve_TP1
cd sauve_TP1
echo Sauvegarde effectuée dans
pwd
echo il contient
ls -l
