#ifndef __LIBTOOLBOX_1_C_GW_H__
#define __LIBTOOLBOX_1_C_GW_H__

#include "c_gateway_prototype.h"

C_GATEWAY_PROTOTYPE(sci_t1_function4);

#endif /* __LIBTOOLBOX_1_C_GW_H__ */
