#!/bin/bash

read n1
read n2
somme=$(expr $n1 + $n2)
echo $n1+$n2=$somme
