#!/bin/bash

echo $RANDOM
echo $RANDOM
